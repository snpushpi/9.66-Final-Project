import numpy as np
import os, sys, math
import random
import math
import scipy.stats

state_set = {'A','B','C','D'}
mu_dict = {'A':.2,'B':.4,'C':.6,'D':.8}
sigma = 0.1

def weight_based_sampling(S): #[[state,weight]]
    states=[e[0] for e in S]
    weights = [e[1] for e in S]
    state =  np.random.choice(states,p=weights) #states [[][]]
    weight = None
    for elt in S:
        if elt[0]==state:
            weight = elt[1]
    return state,weight

def weight_calculate(S):
    weight_dict = {'A':0,'B':0,'C':0,'D':0}
    for state,weight in S:
        weight_dict[state]+=weight
    return weight_dict


class Particle_Filter():

    def __init__(self,particle_num,r):
        self.n = particle_num
        self.S = [[random.choice(tuple(state_set)),1/particle_num] for i in range(particle_num)]
        self.r = r
        self.prediction = None
        self.similarity = None
        self.weight_dict = None

    def update(self,observation, human_observation):
        '''self.S gets updated at each trial.'''
        S_new = []
        eta = 0
        for i in range(self.n):
            state,weight = weight_based_sampling(self.S) #a particle
            x1 = random.uniform(0,1)
            if x1<self.r: #change state - (1-e**(-r*k)) =>
                new_set = state_set-{state}
                state= random.choice(tuple(new_set))
            new_weight = scipy.stats.norm(mu_dict[state],sigma).pdf(observation)
            eta+= new_weight
            S_new.append([state,new_weight])
        S_new = [[elt[0],elt[1]/eta] for elt in S_new]
        self.weight_dict = weight_calculate(S_new)
        self.prediction = max(self.weight_dict, key=self.weight_dict.get)
        self.similarity = self.weight_dict[human_observation]
        self.S = S_new

def run(particle_number,observation_list,human_inference_list,r):
    PF = Particle_Filter(particle_number,r)
    model_inference = []
    for i in range(len(observation_list)):
        PF.update(observation_list[i],human_inference_list[i])
        model_inference.append([PF.prediction, PF.similarity])
    return model_inference

def accuracy_and_similarity(human_inference_list, particle_number, observation_list, actual_list, r):
    '''This function returns both the task accuracy and human similarity measure of the normal
    particle filter model'''

    model_inference_list = run(particle_number,observation_list,human_inference_list,r)
    human_similarity_measure = 0
    task_counter = 0
    for i in range(len(observation_list)):
        human_similarity_measure+=model_inference_list[i][1]
        if actual_list[i]==model_inference_list[i][0]:
            task_counter+=1
    return human_similarity_measure/len(observation_list),task_counter/len(observation_list)

reverse = {1: 'A', 2: 'B', 3: 'C', 4: 'D'}
valsa1 = []
valsa2 = []
valsa3 = []

def solve(actual, human, observation):
    if len(actual) == 0 or (len(valsa1) > 20 and len(valsa2) > 20):
        return

    #print(actual)
    #print(human)
    #print(observation)

    pipe_change = 0
    for i in range(1, len(actual)):
        if actual[i-1] != actual[i]:
            pipe_change += 1

    alpha = pipe_change/float(len(actual)-1)
    if 0.04 <= alpha and alpha <= 0.12:
        x = accuracy_and_similarity(human, 1000, observation, actual, 0.08)[0]
        valsa1.append(x)

    elif 0.12 < alpha and alpha <= .20:
        x = accuracy_and_similarity(human, 1000, observation, actual, 0.16)[0]
        valsa2.append(x)

    elif 0.28 < alpha and alpha <= .36:
        x = accuracy_and_similarity(human, 1000, observation, actual, 0.32)[0]
        valsa3.append(x)



def add_points(files_location):
    for file in os.listdir(files_location):
        if file.endswith(".txt"):
            file_name = os.path.join(files_location, file)
            file = open(file_name)
            data = file.read()
            file.close()
            first = True
            print(file_name)
            #print(data)
            data = data.split('\n')
            actual = []
            human = []
            observation = []
            for line in data:
                if line[0:15] == 'PREDICTION_MODE':
                    # Skip the first set of data as that is the learning stage
                    if not first:
                        solve(actual, human, observation)
                    if len(actual) != 0:
                        first = False
                    actual = []
                    human = []
                    observation = []
                if line[0:12] == 'Release Pipe':
                    #print(line)
                    items = line.split()
                    #print(items)
                    #sys.exit(0)
                    if int(items[3].split("=")[1]) != 0:
                        actual.append(reverse[int(items[1].split("=")[1])])
                        human.append(reverse[int(items[3].split("=")[1])])
                        observation.append(float(items[2].split('=')[1]))

            solve(actual, human, observation)

raw_lab = "PeopleData/between-subj/raw-data-lab"
full_data = "PeopleData/between-subj/full-data-directory-june-2-2008"
raw_web = "PeopleData/between-subj/raw-data-web"

#add_points(full_data)
#add_points(raw_lab)
add_points(raw_web)

print("a1:", valsa1)
print("a2:", valsa2)
print("a3:", valsa3)
