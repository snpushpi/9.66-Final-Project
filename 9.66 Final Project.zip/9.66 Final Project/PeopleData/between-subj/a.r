rm(list=ls())
readdata=function(f) {
  x=scan(f,what="a",quiet=T)
  tmp=options()$warn ; options(warn=-1)
  xn=as.numeric(gsub("[^0-9.]","",x)) # Numeric versions of all fields.
  options(warn=tmp)
  instructions=x[1]
  input=x[2]
  nblk=xn[3]
  dat=array(dim=c(sum(x=="Release"),5),dimnames=list(NULL,
    c("curtopen","pipe","can","resp","rt")))
  blkstats=cbind("mode"=xn[grep("MODE",x)],
    "nf"=xn[grep("FCANS_N",x)],"nd"=xn[grep("DCANS_N",x)])
  tmp=grep("Release",x)
  dat=cbind("pipe"=xn[tmp+1],"can"=xn[tmp+2],"resp"=xn[tmp+3],"rt"=xn[tmp+5])
  curtopen=NULL ; trl=NULL
  for (i in 1:nblk) {
    curtopen=c(curtopen,rep(1:0,times=blkstats[i,c("nf","nd")]))
    trl=c(trl,1:(blkstats[i,"nf"]+blkstats[i,"nd"]))
  }
  dat=cbind(blk=rep(1:nblk,times=blkstats[,"nf"]+blkstats[,"nd"]),trl,curtopen,dat)
  list(instructions=instructions,inputfile=input,nblk=nblk,
    blkinfo=blkstats,dat=dat)
}

checktrls=function(dat,curtainopen) {
  # Check accuracy of task - different for curtain open vs. closed.
  # The check is on whether they make the best guess, if curtain open, 
  # or whether they get it right, if curtain closed.
  if (curtainopen) {
    tmp=cbind(dat[,"pipe"],dat[,"pipe"],dat[,"pipe"],
      as.numeric(cut(dat[,"can"],c(-Inf,.3,.5,.7,+Inf))))
  } else {
    b=as.numeric(cut(dat[,"can"],c(-Inf,.3,.5,.7,+Inf)))
    tmp=cbind(c(dat[-1,"pipe"],NA),c(b[-1],NA),dat[,"pipe"],b)
  }
  tmp1=tmp==matrix(dat[,"resp"],nrow=nrow(dat),ncol=4)
  tmp1[dat[,"trl"]<=cbind(rep(1,nrow(dat)),1,0,0)]=NA
  apply(tmp1,2,mean,na.rm=T)
}

futuredecrement=function(p,alpha) p*(1-alpha)+(1-p)*(alpha/3)

modes=c("nextpipe","nextcan","lastpipe","lastcan")
datdir="raw-data-lab"
fs=dir(datdir,pattern="txt$")
alldat=list(instructions=NULL,inputfile=NULL,nblk=NULL,blkinfo=NULL,dat=NULL,vars=NULL)
for (s in 1:length(fs)) {
  tmp=readdata(paste(datdir,fs[s],sep="/"))
  # Evaluate how accurate each subject's curtain-open and -closed
  # responses were, and also how accurate they would have been under
  # other instructions.
  accs=array(dim=c(tmp$nblk,4,2),dimnames=list(NULL,
    paste("ins",1:4,sep=""),c("open","closed")))
  tmp1=c(NA,diff(tmp$dat[,"resp"]))!=0 ; tmp1[tmp$dat[,"trl"]==1]=NA
  tmp1=tapply(tmp1,tmp$dat[,"curtopen"],sum,na.rm=T)
  tmp1=array(tmp1,dim=c(1,2),dimnames=list(NULL,c("closed","open"))) ; tmp$vars=tmp1
  for (i in 1:tmp$nblk) for (j in 1:0) accs[i,,2-j] = 
     checktrls(tmp$dat[(tmp$dat[,"curtopen"]==j)&(tmp$dat[,"blk"]==i),],
       curtainopen=j)
  tmp$blkinfo=cbind(tmp$blkinfo,accs[,,"open"],accs[,,"closed"])
  for (i in 1:length(tmp)) alldat[[i]]=rbind(alldat[[i]],cbind(s,tmp[[i]]))
}

alldat$mode=tapply(alldat$blkinfo[,"mode"],alldat$blkinfo[,"s"],mean)
# Check subjects to see if they followed their instruction file.
tmp=apply(alldat$blkinfo[,5:8]*alldat$blkinfo[,"nf"],2,
  function(x) tapply(x,alldat$blkinfo[,"s"],sum))
# Look for any subjects where the max number of correct familiarisation
# is either too small (less than xx% right) or those who chose the response
# consistent with some OTHER instruction file more than twice.
bad1=apply(tmp,1,max)<(0.4*tapply(alldat$blkinfo[,"nf"],alldat$blkinfo[,"s"],sum))
bad2=apply(cbind(alldat$mode,tmp),1,function(x) max(x[2:5])-x[x[1]+1])>2
# Also those subjects who were less than xx% right in the decision task.
tmp=apply(alldat$blkinfo[,9:12]*alldat$blkinfo[,"nd"],2,
  function(x) tapply(x,alldat$blkinfo[,"s"],sum))
bad3=apply(tmp,1,max)<(0.4*tapply(alldat$blkinfo[,"nd"],alldat$blkinfo[,"s"],sum))
# Now judge of their WORST block of decision phase.
bad4=.25>=tapply(apply(alldat$blkinfo[,9:12],1,max),alldat$blkinfo[,1],function(x) min(x[-1]))

# Try lots of combos I think 3 or 4 works best.
bad=bad3|bad4


# Count how accuruate the subjects were, in their own conditions.
tmp=apply(alldat$blkinfo[,9:12]*alldat$blkinfo[,"nd"],2,
  function(x) tapply(x,alldat$blkinfo[,"s"],sum))
crossaccs=apply(tmp[!bad,],2,function (x) tapply(x,alldat$mode[!bad],mean))
dimnames(crossaccs)=list(paste("instr",substr(modes,1,1),substr(modes,5,5),sep=""),
  paste("scored",substr(modes,1,1),substr(modes,5,5),sep=""))

print(round(crossaccs))
write.table(cbind(mode=alldat$mode,tmp/matrix(tapply(alldat$blkinfo[,"nd"],
  alldat$blkinfo[,"s"],sum),ncol=4,nrow=length(fs))),
  file="/tmp/webdat.txt",sep="\t",row.names=substr(fs,1,8))
