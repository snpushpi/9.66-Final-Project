#!/bin/bash
if [  ! -d tmp ]
then 
  mkdir tmp
fi
cd tmp
wget -nd --quiet -r -A txt http://psych.newcastle.edu.au/~sdb231/data/
find . -size -1k -exec rm -f '{}' \;

# Delete duplicates
for i in * ; do
  tmp=`head -1 $i | cut -c 1-3`
  if [ $tmp == "web" ]
  then
    dest="web"
  fi
  if [ $tmp == "son" ]
  then
    dest="lab"
  fi
  nm=`echo $i | cut -d"_" -f1`
  tmp=$( ls ../raw-data-$dest )
  counts=$( echo $tmp | grep $nm | wc -l )
  if [ $counts -gt 0 ]
  then
    cp $i ../raw-data-$dest/duplicates
  else
    cp $i ../raw-data-$dest
  fi
done


cd ..
rm -rf tmp

