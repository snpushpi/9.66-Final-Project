import os, sys, math
import matplotlib.pyplot as plt

import numpy as np
import random
import math
import scipy.stats
from collections import Counter

state_set = {'A','B','C','D'}
mu_dict = {'A':.2,'B':.4,'C':.6,'D':.8}
sigma = 0.1

def weight_based_sampling(S): #[[state,weight]]
    states=[e[0] for e in S]
    weights = [e[1] for e in S]
    state =  np.random.choice(states,p=weights)
    weight = None
    for elt in S:
        if elt[0]==state:
            weight = elt[1]
    return state,weight

def most_probable(S):
    weight_dict = {'A':0,'B':0,'C':0,'D':0}
    for state,weight in S:
        weight_dict[state]+=weight
    return max(weight_dict, key=weight_dict.get)

def normpdf(x, mean, sd):
    var = float(sd)**2
    denom = (2*math.pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom


def particle_filter(observation_list,r,particle_num,T):
    '''1. Initialize a list (call it S_0) with a [particle_state,weight] as element(call each element [s_0,w_0]). Initially all weights are equal
       2. Do thw follwing for trial 1 to trial T-
          i) Create an empty list call S_i for storing new particles. Also initialize a normalization constant eta with 0
          for i=1 to i=particle_num do the following -
              ii) at trial j, consider the particle list S_{j-1} and sample a particle from this particle from this distribution based on weight w_{i-1}
              iii) CAll the sampled particle from step ii x_i, now change state with probability alpha, stay in the same state with the rest.
              Call this new particle x_i'
              iv) w_i = P(ith observation|x_i'), eta+=w_i
              v) S_i.append([x_i',w_i])
          for i=1 to i=particle_num:
              w_i/=w_i/eta
    '''
    S = [[random.choice(tuple(state_set)),1/particle_num] for i in range(particle_num)] #S=[[state,1/particle_num]]
    prediction_list = []
    for t in range(1,T+1): #
        S_new = []
        eta = 0
        for i in range(particle_num):
            state,weight = weight_based_sampling(S) #a particle
            x1 = random.uniform(0,1)
            if x1<r: #change state - (1-e**(-r*k)) =>
                new_set = state_set-{state}
                state= random.choice(tuple(new_set))
            #new_weight = scipy.stats.norm(mu_dict[state],sigma).pdf(observation_list[t-1])
            new_weight = normpdf(observation_list[t-1], mu_dict[state],sigma)
            eta+= new_weight
            S_new.append([state,new_weight])
        S_new = [[elt[0],elt[1]/eta] for elt in S_new]
        prediction_list.append(most_probable(S_new))
        S = S_new #S_t - S-
    return prediction_list


vals = {'A': 1, 'B': 2, 'C': 3, 'D': 4}

def count_accuracy(P, r, observation_list, human_list):
    #observation_list,actual_list = data_generate(alpha,T)
    T = len(observation_list)
    prediction_list = particle_filter(observation_list,r,P,T)
    #print(prediction_list)
    count = 0
    for i in range(T):
        if vals[prediction_list[i]]==human_list[i]:
            count+=1
    return count/T

def get_prediction(P, r, observation_list, human_list):
    #observation_list,actual_list = data_generate(alpha,T)
    T = len(observation_list)
    prediction_list = particle_filter(observation_list,r,P,T)
    #print(prediction_list)
    out = []
    for i in range(T):
        out.append( vals[prediction_list[i]] )
    return out

# Figure 7
x1 = []
y1 = []

# alpha (4)
x2 = []

# Figure 4
xa1 = []
ya1 = []
xa2 = []
ya2 = []
xa3 = []
ya3 = []

# Figure 7r
x4 = []
y4 = []

# Alpha (4r)
x7 = []

# Figure 4r
xa4 = []
ya4 = []
xa5 = []
ya5 = []
xa6 = []
ya6 = []

def fig_7_solve(curr):
    N = len(curr)
    if N == 0:
        return
    #print()
    #print(curr)
    correct = 0
    response_change = 0
    for i in range(len(curr)):
        if curr[i][0] == curr[i][1]:
            correct += 1
        if i != 0 and curr[i-1][1] != curr[i][1]:
            response_change += 1

    accuracy = correct/float(N)
    proportion_response_change = response_change/float(N-1)
    #print(accuracy, proportion_response_change)
    x1.append(proportion_response_change)
    y1.append(accuracy)

"""
def get_best_r(curr):
    N = len(curr)
    r_best = 0.0
    r_val = 0.0
    for r in range(0, 100):
        r = r/100.0
        k = 1
        odds = 1.0
        # alpha = 1-e^(-rk), k is the age of the particle
        for i in range(1, N):
            alpha = 1 - math.exp(-r*k) # odds that the response changes
            if curr[i-1][1] != curr[i][1]:
                # The response changes
                odds *= alpha
                k = 1
            else:
                odds *= (1-alpha)
                k += 1

        if odds > r_val:
            r_val = odds
            r_best = r
    return r_best

def log1mexp(a):
    # Avoid underflow
    if a <= math.log(2):
        return math.log(-math.expm1(-a))
    return math.log1p(-math.exp(-a))

def get_best_r(curr):
    N = len(curr)
    r_best = -1
    r_val = 0.0
    for r in range(1, 101):
        r = r/100.0
        k = 1
        odds = 0.0
        # alpha = 1-e^(-rk), k is the age of the particle
        # alpha is the odds that the number changes
        for i in range(1, N):
            if curr[i-1][1] != curr[i][1]:
                # The response changes
                odds += log1mexp(r*k)
                k = 1
            else:
                odds += -r*k
                k += 1

        if odds > r_val or r_best == -1:
            r_val = odds
            r_best = r
    return r_best
"""

def get_best_r(curr):
    N = len(curr)
    r_best = -1
    r_val = 0.0
    observation_list = []
    human_list = []
    for i in curr:
        observation_list.append(i[2])
        human_list.append(i[1])

    for P in range(1, N+1, int(N/10)):
        for r in range(1, 101, 10):
            r = r/100.0
            odds = count_accuracy(P, r, observation_list, human_list)

            if odds > r_val or r_best == -1:
                r_val = odds
                r_best = r
    return r_best



def fig_7_r_solve(curr):
    N = len(curr)
    if N <= 10:
        return

    correct = 0
    for i in range(len(curr)):
        if curr[i][0] == curr[i][1]:
            correct += 1

    r_best = get_best_r(curr)

    #print(curr, r_best)
    #print(N, r_best)

    accuracy = correct/float(N)
    #print(accuracy, proportion_response_change)
    x4.append(r_best)
    y4.append(accuracy)
    print("x:", x4)
    print("y:", y4)

def fig_4_solve(curr):
    N = len(curr)
    if N == 0:
        return
    #print()
    #print(curr)
    correct = 0
    response_change = 0
    pipe_change = 0
    for i in range(len(curr)):
        if curr[i][0] == curr[i][1]:
            correct += 1
        if i != 0 and curr[i-1][1] != curr[i][1]:
            response_change += 1
        if i != 0 and curr[i-1][0] != curr[i][0]:
            pipe_change += 1

    accuracy = correct/float(N)
    proportion_response_change = response_change/float(N-1)
    alpha = pipe_change/float(N-1)
    #print(alpha, len(curr))
    #print(accuracy, proportion_response_change)
    if 0.04 <= alpha and alpha <= 0.12:
        xa1.append(proportion_response_change)
        ya1.append(accuracy)
    elif 0.12 < alpha and alpha <= .20:
        xa2.append(proportion_response_change)
        ya2.append(accuracy)
    elif 0.28 < alpha and alpha <= .36:
        xa3.append(proportion_response_change)
        ya3.append(accuracy)

    x2.append(alpha)

def fig_4_r_solve(curr):
    N = len(curr)
    if N == 0:
        return
    correct = 0
    pipe_change = 0
    for i in range(len(curr)):
        if curr[i][0] == curr[i][1]:
            correct += 1
        if i != 0 and curr[i-1][0] != curr[i][0]:
            pipe_change += 1

    accuracy = correct/float(N)
    best_r = get_best_r(curr)
    alpha = pipe_change/float(N-1)
    #print(alpha, len(curr))
    #print(accuracy, proportion_response_change)
    if 0.04 <= alpha and alpha <= 0.12:
        xa4.append(best_r)
        ya4.append(accuracy)
    elif 0.12 < alpha and alpha <= .20:
        xa5.append(best_r)
        ya5.append(accuracy)
    elif 0.28 < alpha and alpha <= .36:
        xa6.append(best_r)
        ya6.append(accuracy)

    x7.append(alpha)


# Grey Solve data
def grey_solve_7(curr):
    N = len(curr)
    if N == 0:
        return
    # Check if we already have points
    if len(x1) > 500:
        return


    observation_list = []
    human_list = []
    for i in curr:
        observation_list.append(i[2])
        human_list.append(i[1])

    for P in range(1, N+1, int(N/10)):
        for r in range(1, 101, 10):
            r = r/100.0
            prediction = get_prediction(P, r, observation_list, human_list)
            new = []
            for i in range(len(curr)):
                new.append( (curr[i][0], prediction[i]) )
            fig_7_solve(new)

def grey_solve_4(curr):
    N = len(curr)
    if N == 0:
        return
    # Check if we already have points
    if len(xa1) > 500 and len(xa2) > 500:
        return


    observation_list = []
    human_list = []
    for i in curr:
        observation_list.append(i[2])
        human_list.append(i[1])

    for P in range(1, N+1, int(N/10)):
        for r in range(1, 101, 10):
            r = r/100.0
            prediction = get_prediction(P, r, observation_list, human_list)
            new = []
            for i in range(len(curr)):
                new.append( (curr[i][0], prediction[i]) )
            fig_4_solve(new)



def add_points(files_location, solve):
    for file in os.listdir(files_location):
        if file.endswith(".txt"):
            file_name = os.path.join(files_location, file)
            file = open(file_name)
            data = file.read()
            file.close()
            first = True
            print(file_name)
            #print(data)
            data = data.split('\n')
            curr = []
            for line in data:
                if line[0:15] == 'PREDICTION_MODE':
                    # Skip the first set of data as that is the learning stage
                    if not first:
                        solve(curr)
                    if len(curr) != 0:
                        first = False
                    curr = []
                if line[0:12] == 'Release Pipe':
                    items = line.split()
                    #print(items)
                    #sys.exit(0)
                    pipe = int(items[1].split("=")[1])
                    region = int(items[3].split("=")[1])
                    loc = float(items[2].split('=')[1])
                    curr.append((pipe, region, loc))

            solve(curr)

raw_lab = "PeopleData/between-subj/raw-data-lab"
full_data = "PeopleData/between-subj/full-data-directory-june-2-2008"
raw_web = "PeopleData/between-subj/raw-data-web"


def figure7():
    add_points(full_data, fig_7_solve)
    add_points(raw_lab, fig_7_solve)
    add_points(raw_web, fig_7_solve)
    plt.scatter(x1, y1)
    plt.show()


def figure7r():
    #add_points(full_data, fig_7_r_solve)
    #add_points(raw_lab, fig_7_r_solve)

    #add_points(raw_web, fig_7_r_solve)
    #x4 = [0.01, 0.01, 0.01, 0.01, 0.01, 0.51, 0.01, 0.01, 0.31, 0.31, 0.11, 0.91, 0.01, 0.01, 0.01, 0.01, 0.11, 0.41, 0.11, 0.11, 0.31, 0.61, 0.51, 0.41, 0.21, 0.41, 0.11, 0.51, 0.31, 0.51, 0.71, 0.31, 0.01, 0.11, 0.91, 0.01, 0.21, 0.11, 0.01, 0.01, 0.11, 0.81, 0.11, 0.41, 0.01, 0.01, 0.01, 0.01, 0.81, 0.61, 0.31, 0.01, 0.51, 0.71, 0.61, 0.81, 0.01, 0.41, 0.11, 0.11, 0.11, 0.61, 0.91, 0.01, 0.01, 0.11, 0.01, 0.01, 0.71, 0.11, 0.21, 0.91, 0.31, 0.11, 0.51, 0.11, 0.01, 0.01, 0.01, 0.01]
    #y4 = [0.0, 0.0, 0.0, 0.0, 0.44, 0.4418604651162791, 0.0, 0.0, 0.72, 0.7674418604651163, 0.6744186046511628, 0.5116279069767442, 0.0, 0.0, 0.0, 0.0, 0.52, 0.5581395348837209, 0.5581395348837209, 0.4418604651162791, 0.78, 0.7209302325581395, 0.7674418604651163, 0.7674418604651163, 0.62, 0.6744186046511628, 0.6046511627906976, 0.5813953488372093, 0.78, 0.813953488372093, 0.8372093023255814, 0.9069767441860465, 0.58, 0.6046511627906976, 0.27906976744186046, 0.4883720930232558, 0.86, 0.4186046511627907, 0.0, 0.0, 0.4, 0.5581395348837209, 0.5116279069767442, 0.3488372093023256, 0.52, 0.0, 0.0, 0.0, 0.68, 0.7441860465116279, 0.6046511627906976, 0.7906976744186046, 0.72, 0.7209302325581395, 0.7674418604651163, 0.7906976744186046, 0.64, 0.6046511627906976, 0.5813953488372093, 0.5348837209302325, 0.2, 0.23255813953488372, 0.09302325581395349, 0.27906976744186046, 0.44, 0.6976744186046512, 0.46511627906976744, 0.5581395348837209, 0.24, 0.23255813953488372, 0.27906976744186046, 0.23255813953488372, 0.76, 0.8837209302325582, 0.7441860465116279, 0.8837209302325582, 0.0, 0.0, 0.0, 0.0]
    #print("x:", x4)
    #print("y:", y4)
    plt.scatter(x4, y4)
    plt.show()


def figure4():
    add_points(full_data, fig_4_solve)
    add_points(raw_lab, fig_4_solve)
    add_points(raw_web, fig_4_solve)
    plt.title('alpha = 8%')
    plt.scatter(xa1, ya1)
    plt.show()
    plt.title('alpha = 16%')
    plt.scatter(xa2, ya2)
    plt.show()
    plt.title('alpha = 32%')
    plt.scatter(xa3, ya3)
    plt.show()
    plt.hist(x2, 100)
    plt.show()

def figure4r():
    #add_points(full_data, fig_4_r_solve)
    #add_points(raw_lab, fig_4_r_solve)
    add_points(raw_web, fig_4_r_solve)
    plt.title('alpha = 8%')
    plt.scatter(xa4, ya4)
    plt.show()
    plt.title('alpha = 16%')
    plt.scatter(xa5, ya5)
    plt.show()
    plt.title('alpha = 32%')
    plt.scatter(xa6, ya6)
    plt.show()
    plt.hist(x7, 100)
    plt.show()


def greydots():
    add_points(raw_web, grey_solve_7)
    plt.scatter(x1, y1)
    plt.show()
    """add_points(raw_web, grey_solve_4)
    plt.title('alpha = 8%')
    plt.scatter(xa1, ya1)
    plt.show()
    plt.title('alpha = 16%')
    plt.scatter(xa2, ya2)
    plt.show()
    plt.title('alpha = 32%')
    plt.scatter(xa3, ya3)
    plt.show()
    plt.hist(x2, 100)
    plt.show()"""



figure7()
#figure7r()
figure4()
#figure4r()
#greydots()
